﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.DTOs
{
    public class FilterProductRqstDTO
    {
        public string FilterTerm { get; set; }
    }
}
